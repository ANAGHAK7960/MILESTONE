use milestone;
select * from milestone.`milestone project`;

SELECT 
    Industry, 
    Gender, 
    AVG(Annual_Salary) AS average_salary
FROM milestone.`milestone project`
GROUP BY industry, gender
ORDER BY industry, gender;

select 
	Job_title,
    sum(Annual_salary+Additional_Monetary_Compensation) AS total
    from milestone.`milestone project`
GROUP BY Job_title
ORDER BY total desc;

select
	Qualification,
    avg(Annual_salary) as average_salary,
    min(Annual_salary) as minimum_salary,
	max(Annual_salary) as miximum_salary
    from milestone.`milestone project`
GROUP BY Qualification
ORDER BY average_salary desc;

select
	Industry,
    Professional_experience,
    count(*) as emp_count
    from milestone.`milestone project`
GROUP BY industry,professional_experience
ORDER BY emp_count desc;
    
WITH RankedSalaries AS (
    SELECT 
        Annual_salary,
        age_range,
        gender,
        ROW_NUMBER() OVER (PARTITION BY age_range, gender ORDER BY Annual_salary) AS row_num,
        COUNT(*) OVER (PARTITION BY age_range, gender) AS total_count
    FROM milestone.`milestone project`
)
SELECT age_range, gender,
       CASE 
           WHEN total_count % 2 = 1 THEN
		
               MAX(CASE WHEN row_num = (total_count + 1) / 2 THEN Annual_salary END) 
           ELSE
	
              AVG(CASE WHEN row_num IN (total_count / 2, total_count / 2 + 1) THEN Annual_salary END)
       END AS median_salary
FROM RankedSalaries
GROUP BY age_range, gender
ORDER BY age_range, gender;


select
	City,
    Industry,
    avg(Annual_Salary) as average_salary
    from milestone.`milestone project`
GROUP BY City,industry
ORDER BY average_salary desc;

select
	Country,
    Job_title,
    max(Annual_Salary) as highest_salary
from milestone.`milestone project`
GROUP BY country,job_title
ORDER BY highest_salary desc;

select
	Gender,
    round(count(CASE WHEN Additional_Monetary_Compensation >0 THEN 1 END)
    *100.0/COUNT(*),2) AS percentage_compensation 
    from milestone.`milestone project`
GROUP BY gender
ORDER BY gender;

select
	Job_title,
    Professional_Experience,
    sum(Annual_Salary+Additional_Monetary_Compensation) as total_compensation
from milestone.`milestone project`
GROUP BY Job_title,Professional_Experience
ORDER BY total_compensation desc;

select
	Industry,
    Gender,
    Qualification as education_level,
    avg(Annual_Salary) as average_salary
from milestone.`milestone project`
GROUP BY industry,gender,Qualification
ORDER BY average_salary desc;